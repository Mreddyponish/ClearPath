# ClearPath: Emergency Route Planner

ClearPath is a MERN-stack hackathon prototype for graph-based emergency route planning. It supports route requests for ambulance, fire, and police scenarios, road-network administration, route history, analytics, and a React-Leaflet map.

> **Safety notice:** ClearPath is a demonstration system. It does not use verified live traffic or dispatch data and must not be used as a substitute for official emergency services. In a real emergency, contact your local official emergency number.

## Requirements
- Node.js 20 or later
- MongoDB local instance or MongoDB Atlas
- Internet connection for the default OpenStreetMap tiles and Google Fonts

## Quick start
1. Copy `server/.env.example` to `server/.env` and set `MONGO_URI` and a long `JWT_SECRET`.
2. Install dependencies:
   ```bash
   npm install
   npm run install:all
   ```
3. Seed the sample graph:
   ```bash
   npm run seed
   ```
4. Start both apps:
   ```bash
   npm run dev
   ```
5. Open the Vite URL shown in the terminal (normally http://localhost:5173).

## Demo accounts
The seed script creates these local demonstration accounts. Change their passwords before any shared deployment:
- Admin: `admin@clearpath.demo` / `ClearPathAdmin123!`
- User: `user@clearpath.demo` / `ClearPathUser123!`

## Architecture
- `client/`: React + Vite interface, React Router, Axios, React-Leaflet, Recharts.
- `server/`: Express REST API, Mongoose models, JWT auth, validation, Dijkstra route utility, seed script, tests.

## Route algorithm
The server represents locations as graph vertices and roads as edges. Blocked roads are excluded. Dijkstra's algorithm uses a non-negative edge cost configured for the selected emergency type:
- Ambulance: estimated time with stronger high-traffic penalty.
- Fire: distance with a moderate traffic penalty.
- Police: a balanced distance/time score.
The displayed ETA is estimated from stored road base-time values and traffic penalties, not live traffic data. With an adjacency list and binary min-heap, the typical complexity is `O((V + E) log V)` time and `O(V + E)` space.

The alternate route implementation temporarily removes each edge of the primary path in turn and selects the lowest-cost distinct route among the candidates. It may return no alternative if the network has no viable alternative.

## API overview
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `GET /api/locations`; admin: `POST`, `PUT /:id`, `DELETE /:id`
- `GET /api/roads`; admin: `POST`, `PUT /:id`, `DELETE /:id`, `PATCH /:id/block`
- `POST /api/routes/find` with `{ "sourceId": "...", "destinationId": "...", "emergencyType": "ambulance" }`
- `GET /api/routes/history`
- `DELETE /api/routes/history/:id`
- `GET /api/analytics/summary` (admin only)

## Quality checklist
Run the app and verify before claiming these items are complete:
- [ ] No horizontal overflow at 320, 375, 768, and 1280px.
- [ ] Mobile menu opens, closes on route change and Escape, and supports keyboard navigation.
- [ ] All navigation and footer links resolve.
- [ ] Every page has a unique title and description.
- [ ] Favicon is loaded.
- [ ] Buttons have working handlers, loading states, and appropriate types.
- [ ] Auth and admin permissions are enforced by the backend.
- [ ] Route history is scoped to the authenticated user.
- [ ] Dijkstra tests pass.
- [ ] Error and success feedback is visible.
- [ ] Screenshots and performance measurements are collected from the running application.

## Limitations
This prototype uses seeded/sample road data. It does not connect to a live traffic feed, official emergency dispatch, or validated incident service. ETA and route suitability depend on sample data and configurable weights.
