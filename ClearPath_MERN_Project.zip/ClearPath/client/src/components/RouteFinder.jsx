import { useEffect, useState } from 'react';
import api, { getErrorMessage } from '../api.js';
import MapView from './MapView.jsx';
import { useAuth } from '../context/AuthContext.jsx';

export default function RouteFinder() {
  const { user } = useAuth();
  const [locations, setLocations] = useState([]);
  const [roads, setRoads] = useState([]);
  const [sourceId, setSourceId] = useState('');
  const [destinationId, setDestinationId] = useState('');
  const [emergencyType, setEmergencyType] = useState('ambulance');
  const [result, setResult] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  useEffect(() => {
    Promise.all([api.get('/locations'), api.get('/roads')]).then(([l,r]) => {
      setLocations(l.data.locations); setRoads(r.data.roads);
      if (l.data.locations.length > 1) { setSourceId(String(l.data.locations[0]._id)); setDestinationId(String(l.data.locations[1]._id)); }
    }).catch(e => setError(getErrorMessage(e)));
  }, []);
  async function submit(e) {
    e.preventDefault(); setError(''); setNotice(''); setResult(null);
    if (!user) { setError('Sign in to calculate and save a route.'); return; }
    if (!sourceId || !destinationId) { setError('Choose both a source and a destination.'); return; }
    setBusy(true);
    try {
      const response = await api.post('/routes/find', { sourceId, destinationId, emergencyType });
      setResult(response.data); setNotice(response.data.message);
    } catch (e) { setError(getErrorMessage(e)); }
    finally { setBusy(false); }
  }
  const findById = id => locations.find(x => String(x._id) === String(id));
  return <section className="route-tool">
    <div className="route-form-panel">
      <p className="eyebrow">ROUTE PLANNING</p><h2>Find a route</h2>
      <p>Select a scenario and two locations. Results use the project's stored sample road network.</p>
      <form onSubmit={submit} className="form-stack">
        <label>Emergency type<select value={emergencyType} onChange={e => setEmergencyType(e.target.value)}><option value="ambulance">Ambulance</option><option value="fire">Fire service</option><option value="police">Police</option></select></label>
        <label>Source location<select required value={sourceId} onChange={e => setSourceId(e.target.value)}><option value="">Choose source</option>{locations.map(l => <option key={l._id} value={l._id}>{l.name}</option>)}</select></label>
        <label>Destination<select required value={destinationId} onChange={e => setDestinationId(e.target.value)}><option value="">Choose destination</option>{locations.map(l => <option key={l._id} value={l._id}>{l.name}</option>)}</select></label>
        <button type="submit" disabled={busy || !locations.length}>{busy ? 'Calculating route…' : 'Calculate route'}</button>
      </form>
      {!user && <p className="inline-note">Sign in is required to save a route request.</p>}
      {error && <p className="feedback error" role="alert">{error}</p>}
      {notice && <p className="feedback success" role="status">{notice}</p>}
      {result?.route && <div className="route-results"><h3>Selected route</h3><div className="metric-row"><div><span>Distance</span><strong>{result.route.totalDistance} km</strong></div><div><span>Estimated time</span><strong>{result.route.eta} min</strong></div></div>
        <p><strong>Path:</strong> {result.route.path.map(p => p.name).join(' → ')}</p>
        {result.alternateRoute && <p><strong>Alternative:</strong> {result.alternateRoute.path.map(p => p.name).join(' → ')}</p>}
        <p className="small-note">{result.notice}</p>
      </div>}
    </div>
    <div className="route-map-panel"><MapView locations={locations} roads={roads} route={result?.route?.path ?? []} alternate={result?.alternateRoute?.path ?? []} /></div>
  </section>;
}
