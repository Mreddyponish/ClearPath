import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import { useEffect } from 'react';
import L from 'leaflet';

const markerIcon = new L.Icon({
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
  iconSize: [25, 41], iconAnchor: [12, 41]
});
function FitRoute({ points }) {
  const map = useMap();
  useEffect(() => { if (points.length) map.fitBounds(points, { padding: [24, 24], maxZoom: 14 }); }, [map, points]);
  return null;
}
export default function MapView({ locations = [], roads = [], route = [], alternate = [] }) {
  const routePoints = route.map(p => [Number(p.lat), Number(p.lng)]);
  const alternatePoints = alternate.map(p => [Number(p.lat), Number(p.lng)]);
  return <div className="map-frame">
    <MapContainer center={[17.44, 78.50]} zoom={12} scrollWheelZoom className="map">
      <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
      {roads.map(road => {
        const a = road.from, b = road.to;
        if (!a?.lat || !b?.lat) return null;
        return <Polyline key={road._id} positions={[[a.lat,a.lng],[b.lat,b.lng]]}
          pathOptions={{ color: road.isBlocked ? '#a52a2a' : '#8b9295', weight: road.trafficLevel === 'high' ? 5 : road.trafficLevel === 'medium' ? 3 : 2, dashArray: road.isBlocked ? '7 7' : undefined, opacity: road.isBlocked ? 0.8 : 0.55 }} />;
      })}
      {locations.map(loc => <Marker key={loc._id} position={[loc.lat,loc.lng]} icon={markerIcon}><Popup><strong>{loc.name}</strong><br />{loc.type}</Popup></Marker>)}
      {alternatePoints.length > 1 && <Polyline positions={alternatePoints} pathOptions={{ color: '#777d80', weight: 4, dashArray: '4 7' }} />}
      {routePoints.length > 1 && <Polyline positions={routePoints} pathOptions={{ color: '#a52a2a', weight: 6 }} />}
      <FitRoute points={routePoints.length ? routePoints : locations.slice(0, 8).map(p => [p.lat,p.lng])} />
    </MapContainer>
    <p className="map-attribution">Map data © OpenStreetMap contributors. Red solid: selected route. Dashed red roads: blocked.</p>
  </div>;
}
