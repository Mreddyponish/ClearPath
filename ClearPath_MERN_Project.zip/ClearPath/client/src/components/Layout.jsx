import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { useEffect, useRef, useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
const baseLinks = [['/', 'Home'], ['/find-route', 'Find Route'], ['/history', 'Route History'], ['/about', 'About'], ['/contact', 'Contact']];
export default function Layout() {
  const { user, signOut } = useAuth();
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const panelRef = useRef(null);
  useEffect(() => { setOpen(false); }, [location.pathname]);
  useEffect(() => {
    if (!open) return;
    const onKey = e => {
      if (e.key === 'Escape') setOpen(false);
      if (e.key === 'Tab' && panelRef.current) {
        const els = [...panelRef.current.querySelectorAll('a,button')].filter(el => !el.disabled);
        if (!els.length) return;
        if (e.shiftKey && document.activeElement === els[0]) { e.preventDefault(); els[els.length - 1].focus(); }
        else if (!e.shiftKey && document.activeElement === els[els.length - 1]) { e.preventDefault(); els[0].focus(); }
      }
    };
    document.addEventListener('keydown', onKey);
    panelRef.current?.querySelector('a,button')?.focus();
    return () => document.removeEventListener('keydown', onKey);
  }, [open]);
  const links = [...baseLinks, ...(user?.role === 'admin' ? [['/admin/locations','Admin Locations'], ['/admin/roads','Admin Roads'], ['/admin/analytics','Admin Analytics']] : [])];
  return <><header className="site-header"><div className="header-inner">
    <Link to="/" className="brand" aria-label="ClearPath home"><span className="brand-mark">C</span><span>ClearPath</span></Link>
    <button className="menu-toggle" type="button" aria-expanded={open} aria-controls="mobile-navigation" onClick={() => setOpen(v => !v)}>{open ? 'Close menu' : 'Menu'}</button>
    <nav className="desktop-nav" aria-label="Main navigation">{links.map(([to,label]) => <NavLink key={to} to={to}>{label}</NavLink>)}
      {user ? <button type="button" className="text-button" onClick={signOut}>Sign out</button> : <Link to="/login">Sign in</Link>}
    </nav>
  </div>
  {open && <nav ref={panelRef} id="mobile-navigation" className="mobile-nav" aria-label="Mobile navigation">
    {links.map(([to,label]) => <NavLink key={to} to={to}>{label}</NavLink>)}
    {user ? <button type="button" onClick={signOut}>Sign out</button> : <Link to="/login">Sign in</Link>}
  </nav>}</header>
  <main className="page-shell"><Outlet /></main>
  <footer className="site-footer"><div className="footer-inner"><p><strong>ClearPath</strong><br />Emergency route planning demonstration.</p><nav aria-label="Footer links"><Link to="/">Home</Link><Link to="/find-route">Find Route</Link><Link to="/about">About</Link><Link to="/contact">Contact</Link><Link to="/terms">Terms of Service</Link><Link to="/privacy">Privacy Policy</Link></nav><p className="notice">For a real emergency, contact your official emergency number.</p><small>© {new Date().getFullYear()} ClearPath</small></div></footer></>;
}
