import axios from 'axios';
const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api' });
api.interceptors.request.use(config => {
  const token = localStorage.getItem('clearpath_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});
export function getErrorMessage(error) {
  if (error.response?.data?.message) return error.response.data.message;
  if (error.request) return 'The server could not be reached. Check that the API is running and try again.';
  return 'Something went wrong. Please try again.';
}
export default api;
