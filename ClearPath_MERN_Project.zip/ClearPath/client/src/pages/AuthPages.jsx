import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api, { getErrorMessage } from '../api.js';
import { useAuth } from '../context/AuthContext.jsx';
import Seo from '../components/Seo.jsx';

export function Login() {
  const [form, setForm] = useState({ email: '', password: '' });
  const [busy, setBusy] = useState(false), [error, setError] = useState('');
  const { signIn } = useAuth(); const navigate = useNavigate();
  async function submit(e) { e.preventDefault(); setBusy(true); setError(''); try { const { data } = await api.post('/auth/login', form); signIn(data); navigate('/'); } catch (e) { setError(getErrorMessage(e)); } finally { setBusy(false); } }
  return <><Seo title="Login" description="Sign in to ClearPath to calculate routes and review your route history." /><div className="auth-panel"><p className="eyebrow">ACCOUNT ACCESS</p><h1>Sign in</h1><p>Use your ClearPath account to calculate and save a route.</p><form onSubmit={submit} className="form-stack"><label>Email<input type="email" autoComplete="email" required value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></label><label>Password<input type="password" autoComplete="current-password" required value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/></label>{error && <p className="feedback error" role="alert">{error}</p>}<button disabled={busy} type="submit">{busy?'Signing in…':'Sign in'}</button></form><p>New to ClearPath? <Link to="/register">Create an account</Link>.</p><p className="small-note">Demo accounts are documented in the project README.</p></div></>;
}
export function Register() {
  const [form, setForm] = useState({ name:'', email:'', password:'' });
  const [busy, setBusy] = useState(false), [error, setError] = useState(''), [success, setSuccess] = useState('');
  const { signIn } = useAuth(); const navigate = useNavigate();
  async function submit(e) { e.preventDefault(); setBusy(true); setError(''); setSuccess(''); try { const { data } = await api.post('/auth/register', form); signIn(data); setSuccess(data.message); navigate('/'); } catch (e) { setError(getErrorMessage(e)); } finally { setBusy(false); } }
  return <><Seo title="Register" description="Create a ClearPath account to try the emergency route planner and save your route requests." /><div className="auth-panel"><p className="eyebrow">NEW ACCOUNT</p><h1>Create account</h1><form onSubmit={submit} className="form-stack"><label>Full name<input required minLength="2" maxLength="80" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></label><label>Email<input type="email" required autoComplete="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></label><label>Password<input type="password" required minLength="8" autoComplete="new-password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/><small>Use at least 8 characters.</small></label><p className="small-note">By registering, you acknowledge the <Link to="/terms">Terms of Service</Link> and <Link to="/privacy">Privacy Policy</Link>.</p>{error && <p className="feedback error" role="alert">{error}</p>}{success && <p className="feedback success" role="status">{success}</p>}<button disabled={busy} type="submit">{busy?'Creating account…':'Create account'}</button></form><p>Already registered? <Link to="/login">Sign in</Link>.</p></div></>;
}
