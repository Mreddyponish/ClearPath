import Seo from '../components/Seo.jsx';
import RouteFinder from '../components/RouteFinder.jsx';
export default function FindRoute() {
  return <><Seo title="Find Route" description="Choose an emergency type, source, and destination to calculate a route using ClearPath's sample road graph." /><div className="page-intro"><p className="eyebrow">ROUTE TOOL</p><h1>Find Route</h1><p>Choose an emergency type, then calculate a path through the available sample road network.</p></div><RouteFinder /></>;
}
