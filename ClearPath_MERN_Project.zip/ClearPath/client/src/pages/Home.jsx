import { Link } from 'react-router-dom';
import Seo from '../components/Seo.jsx';
import RouteFinder from '../components/RouteFinder.jsx';
export default function Home() {
  return <><Seo title="Home" description="Explore ClearPath, a hackathon demonstration that calculates emergency routes using a sample road network and graph algorithms." />
    <section className="hero"><div><p className="eyebrow">EMERGENCY ROUTE PLANNING / HACKATHON PROJECT</p><h1>Make the route decision visible.</h1><p className="hero-copy">ClearPath models roads, traffic levels, and roadblocks to demonstrate how graph algorithms can support emergency route planning.</p><div className="hero-actions"><Link className="button-link" to="/find-route">Open route planner</Link><Link className="plain-link" to="/about">Explore the project</Link></div></div><aside className="hero-aside"><span className="aside-number">01 / 03</span><h2>Three emergency priorities</h2><p>Ambulance: time-focused. Fire service: distance-focused. Police: balanced route cost.</p><p className="small-note">Sample data only. No live traffic feed.</p></aside></section>
    <section className="section-block"><div className="section-heading"><div><p className="eyebrow">LIVE PRODUCT DEMO</p><h2>Try a sample route</h2></div><p>Sign in to run a route request against the seeded database and see it drawn on the map.</p></div><RouteFinder /></section>
    <section className="section-block split-section"><div><p className="eyebrow">SYSTEM APPROACH</p><h2>A route is a graph problem.</h2></div><div><p>Locations become graph nodes. Roads become weighted edges. The server excludes blocked roads and calculates a path using the selected emergency cost model.</p><p>Administrators maintain the network, while route requests and summaries are stored for review.</p></div></section>
    <div className="safety-banner"><strong>Important safety notice</strong><p>ClearPath is a hackathon prototype, not an operational emergency navigation service. For a real emergency, contact your official emergency number.</p></div>
  </>;
}
