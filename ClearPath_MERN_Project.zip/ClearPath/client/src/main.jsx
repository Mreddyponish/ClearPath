import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import App from './App.jsx';
import { AuthProvider } from './context/AuthContext.jsx';
import './styles.css';
import 'leaflet/dist/leaflet.css';

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <HelmetProvider><BrowserRouter><AuthProvider><App /></AuthProvider></BrowserRouter></HelmetProvider>
  </React.StrictMode>
);
