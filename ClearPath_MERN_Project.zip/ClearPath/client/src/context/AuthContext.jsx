import { createContext, useContext, useEffect, useState } from 'react';
import api from '../api.js';
const AuthContext = createContext(null);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const token = localStorage.getItem('clearpath_token');
    if (!token) { setReady(true); return; }
    api.get('/auth/me').then(r => setUser(r.data.user)).catch(() => localStorage.removeItem('clearpath_token')).finally(() => setReady(true));
  }, []);
  const signIn = data => { localStorage.setItem('clearpath_token', data.token); setUser(data.user); };
  const signOut = () => { localStorage.removeItem('clearpath_token'); setUser(null); };
  return <AuthContext.Provider value={{ user, ready, signIn, signOut }}>{children}</AuthContext.Provider>;
}
export const useAuth = () => useContext(AuthContext);
