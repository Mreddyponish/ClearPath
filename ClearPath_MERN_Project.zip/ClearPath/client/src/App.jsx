import { Navigate, Route, Routes } from 'react-router-dom';
import Layout from './components/Layout.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';
import Home from './pages/Home.jsx';
import FindRoute from './pages/FindRoute.jsx';
import { Login, Register } from './pages/AuthPages.jsx';
import History from './pages/History.jsx';
import { AdminLocations, AdminRoads, AdminAnalytics } from './pages/Admin.jsx';
import { About, Contact, Terms, Privacy, NotFound } from './pages/InfoPages.jsx';

export default function App() {
  return <Routes><Route element={<Layout />}>
    <Route index element={<Home />} />
    <Route path="find-route" element={<FindRoute />} />
    <Route path="about" element={<About />} /><Route path="contact" element={<Contact />} />
    <Route path="terms" element={<Terms />} /><Route path="privacy" element={<Privacy />} />
    <Route path="login" element={<Login />} /><Route path="register" element={<Register />} />
    <Route element={<ProtectedRoute />}><Route path="history" element={<History />} /></Route>
    <Route element={<ProtectedRoute admin />}><Route path="admin/locations" element={<AdminLocations />} /><Route path="admin/roads" element={<AdminRoads />} /><Route path="admin/analytics" element={<AdminAnalytics />} /></Route>
    <Route path="404" element={<NotFound />} /><Route path="*" element={<NotFound />} />
  </Route></Routes>;
}
