export const contact = {
  phone: import.meta.env.VITE_CONTACT_PHONE || '',
  email: import.meta.env.VITE_CONTACT_EMAIL || ''
};
