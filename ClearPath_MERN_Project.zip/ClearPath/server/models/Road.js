import mongoose from 'mongoose';

const roadSchema = new mongoose.Schema({
  from: { type: mongoose.Schema.Types.ObjectId, ref: 'Location', required: true },
  to: { type: mongoose.Schema.Types.ObjectId, ref: 'Location', required: true },
  distance: { type: Number, required: true, min: 0.01 },
  baseTime: { type: Number, required: true, min: 0.1 },
  trafficLevel: { type: String, enum: ['low', 'medium', 'high'], default: 'low' },
  isBlocked: { type: Boolean, default: false },
  bidirectional: { type: Boolean, default: true }
}, { timestamps: true });

roadSchema.index({ from: 1, to: 1 }, { unique: true });
export default mongoose.model('Road', roadSchema);
