import mongoose from 'mongoose';

const routeRequestSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  source: { type: mongoose.Schema.Types.ObjectId, ref: 'Location', required: true },
  destination: { type: mongoose.Schema.Types.ObjectId, ref: 'Location', required: true },
  emergencyType: { type: String, enum: ['ambulance', 'fire', 'police'], required: true },
  path: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Location' }],
  totalDistance: { type: Number, required: true, min: 0 },
  eta: { type: Number, required: true, min: 0 },
  createdAt: { type: Date, default: Date.now }
}, { timestamps: false });

export default mongoose.model('RouteRequest', routeRequestSchema);
