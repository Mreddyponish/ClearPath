import mongoose from 'mongoose';

const locationSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 100 },
  lat: { type: Number, required: true, min: -90, max: 90 },
  lng: { type: Number, required: true, min: -180, max: 180 },
  type: { type: String, enum: ['junction', 'hospital', 'fire station', 'police station'], default: 'junction' }
}, { timestamps: true });

export default mongoose.model('Location', locationSchema);
