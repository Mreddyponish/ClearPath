import RouteRequest from '../models/RouteRequest.js';
import Road from '../models/Road.js';

export async function summary(req, res, next) {
  try {
    const [byType, mostUsed, mostBlocked] = await Promise.all([
      RouteRequest.aggregate([
        { $group: { _id: '$emergencyType', requests: { $sum: 1 }, averageEta: { $avg: '$eta' } } },
        { $sort: { requests: -1 } }
      ]),
      RouteRequest.aggregate([
        { $unwind: '$path' }, { $group: { _id: '$path', uses: { $sum: 1 } } },
        { $sort: { uses: -1 } }, { $limit: 5 },
        { $lookup: { from: 'locations', localField: '_id', foreignField: '_id', as: 'location' } },
        { $unwind: { path: '$location', preserveNullAndEmptyArrays: true } },
        { $project: { name: '$location.name', uses: 1 } }
      ]),
      Road.aggregate([
        { $match: { isBlocked: true } }, { $group: { _id: '$trafficLevel', count: { $sum: 1 } } }
      ])
    ]);
    res.json({ byType, mostUsed, blockedRoads: mostBlocked });
  } catch (e) { next(e); }
}
