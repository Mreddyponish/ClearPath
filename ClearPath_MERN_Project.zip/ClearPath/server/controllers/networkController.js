import Location from '../models/Location.js';
import Road from '../models/Road.js';

export async function listLocations(req, res, next) {
  try { res.json({ locations: await Location.find().sort({ name: 1 }) }); } catch (e) { next(e); }
}
export async function createLocation(req, res, next) {
  try { res.status(201).json({ location: await Location.create(req.body), message: 'Location created.' }); } catch (e) { next(e); }
}
export async function updateLocation(req, res, next) {
  try {
    const location = await Location.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!location) return res.status(404).json({ message: 'Location not found.' });
    res.json({ location, message: 'Location updated.' });
  } catch (e) { next(e); }
}
export async function deleteLocation(req, res, next) {
  try {
    const location = await Location.findById(req.params.id);
    if (!location) return res.status(404).json({ message: 'Location not found.' });
    const connected = await Road.exists({ $or: [{ from: location._id }, { to: location._id }] });
    if (connected) return res.status(409).json({ message: 'Remove connected roads before deleting this location.' });
    await location.deleteOne();
    res.json({ message: 'Location deleted.' });
  } catch (e) { next(e); }
}
export async function listRoads(req, res, next) {
  try { res.json({ roads: await Road.find().populate('from to').sort({ createdAt: 1 }) }); } catch (e) { next(e); }
}
export async function createRoad(req, res, next) {
  try { res.status(201).json({ road: await Road.create(req.body), message: 'Road created.' }); } catch (e) { next(e); }
}
export async function updateRoad(req, res, next) {
  try {
    const road = await Road.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true }).populate('from to');
    if (!road) return res.status(404).json({ message: 'Road not found.' });
    res.json({ road, message: 'Road updated.' });
  } catch (e) { next(e); }
}
export async function deleteRoad(req, res, next) {
  try {
    const road = await Road.findByIdAndDelete(req.params.id);
    if (!road) return res.status(404).json({ message: 'Road not found.' });
    res.json({ message: 'Road deleted.' });
  } catch (e) { next(e); }
}
export async function toggleBlock(req, res, next) {
  try {
    const road = await Road.findById(req.params.id);
    if (!road) return res.status(404).json({ message: 'Road not found.' });
    road.isBlocked = !road.isBlocked;
    await road.save();
    res.json({ road, message: road.isBlocked ? 'Road marked as blocked.' : 'Road reopened.' });
  } catch (e) { next(e); }
}
