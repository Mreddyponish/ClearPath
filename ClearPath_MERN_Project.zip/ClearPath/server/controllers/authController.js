import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { validationResult } from 'express-validator';
import User from '../models/User.js';

function tokenFor(user) {
  return jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '12h' });
}
function safeUser(user) {
  return { id: user._id, name: user.name, email: user.email, role: user.role };
}
export async function register(req, res, next) {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ message: 'Please correct the highlighted fields.', errors: errors.array() });
    const { name, email, password } = req.body;
    const existing = await User.findOne({ email: email.toLowerCase() });
    if (existing) return res.status(409).json({ message: 'An account with this email already exists.' });
    const user = await User.create({ name, email, password: await bcrypt.hash(password, 12), role: 'user' });
    res.status(201).json({ message: 'Account created. You can now find a route.', token: tokenFor(user), user: safeUser(user) });
  } catch (err) { next(err); }
}
export async function login(req, res, next) {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email: String(email).toLowerCase() }).select('+password');
    if (!user || !(await bcrypt.compare(String(password ?? ''), user.password))) {
      return res.status(401).json({ message: 'Email or password is incorrect.' });
    }
    res.json({ message: 'Signed in successfully.', token: tokenFor(user), user: safeUser(user) });
  } catch (err) { next(err); }
}
export async function me(req, res) {
  res.json({ user: safeUser(req.user) });
}
