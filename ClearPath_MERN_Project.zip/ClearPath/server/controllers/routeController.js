import Location from '../models/Location.js';
import Road from '../models/Road.js';
import RouteRequest from '../models/RouteRequest.js';
import { findShortestPath, findAlternatePath, summarizePath } from '../utils/dijkstra.js';

function routePayload(result, locationMap) {
  return {
    path: result.path.map(id => locationMap.get(id)).filter(Boolean),
    totalDistance: summarizePath(result).totalDistance,
    eta: summarizePath(result).eta,
    cost: Number(result.cost.toFixed(2))
  };
}
export async function findRoute(req, res, next) {
  try {
    const { sourceId, destinationId, emergencyType } = req.body;
    if (!sourceId || !destinationId || !['ambulance', 'fire', 'police'].includes(emergencyType)) {
      return res.status(400).json({ message: 'Choose a source, destination, and valid emergency type.' });
    }
    const [locations, roads] = await Promise.all([Location.find(), Road.find()]);
    const args = { locations, roads, sourceId, destinationId, emergencyType };
    const result = findShortestPath(args);
    if (!result) return res.status(404).json({ message: 'No route is available between these locations with the current road conditions.' });
    const alternate = findAlternatePath(args, result);
    const locationMap = new Map(locations.map(loc => [String(loc._id), loc]));
    const main = routePayload(result, locationMap);
    const alt = alternate ? routePayload(alternate, locationMap) : null;
    const saved = await RouteRequest.create({
      user: req.user._id, source: sourceId, destination: destinationId, emergencyType,
      path: result.path, totalDistance: main.totalDistance, eta: main.eta
    });
    res.json({
      message: 'Route found. Review road conditions before making any real-world decision.',
      route: main,
      alternateRoute: alt,
      requestId: saved._id,
      notice: 'Estimated values use stored sample road data, not live traffic.'
    });
  } catch (e) { next(e); }
}
export async function history(req, res, next) {
  try {
    const query = req.user.role === 'admin' ? {} : { user: req.user._id };
    const records = await RouteRequest.find(query)
      .populate('user', 'name email').populate('source destination path').sort({ createdAt: -1 }).limit(200);
    res.json({ history: records });
  } catch (e) { next(e); }
}
export async function deleteHistory(req, res, next) {
  try {
    const query = req.user.role === 'admin' ? { _id: req.params.id } : { _id: req.params.id, user: req.user._id };
    const record = await RouteRequest.findOneAndDelete(query);
    if (!record) return res.status(404).json({ message: 'History record not found or you do not have permission to delete it.' });
    res.json({ message: 'History record deleted.' });
  } catch (e) { next(e); }
}
