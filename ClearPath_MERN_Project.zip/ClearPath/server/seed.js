import 'dotenv/config';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import { connectDB } from './config/db.js';
import User from './models/User.js';
import Location from './models/Location.js';
import Road from './models/Road.js';

const sampleLocations = [
  ['Central Junction',17.4399,78.4983,'junction'], ['City Hospital',17.4435,78.5010,'hospital'],
  ['North Junction',17.4510,78.4980,'junction'], ['Fire Station 1',17.4460,78.4900,'fire station'],
  ['Police Station 1',17.4350,78.4920,'police station'], ['Market Junction',17.4320,78.5030,'junction'],
  ['East Junction',17.4400,78.5120,'junction'], ['Community Hospital',17.4470,78.5150,'hospital'],
  ['South Junction',17.4250,78.4980,'junction'], ['West Junction',17.4390,78.4800,'junction'],
  ['Fire Station 2',17.4200,78.5100,'fire station'], ['Police Station 2',17.4550,78.5100,'police station'],
  ['Lake Road Junction',17.4600,78.4900,'junction'], ['School Junction',17.4520,78.4800,'junction'],
  ['Metro Junction',17.4300,78.4800,'junction'], ['Old Town Junction',17.4250,78.4870,'junction'],
  ['Railway Junction',17.4170,78.4970,'junction'], ['East Market',17.4320,78.5200,'junction'],
  ['West Hospital',17.4480,78.4760,'hospital'], ['River Junction',17.4620,78.5050,'junction'],
  ['Garden Junction',17.4650,78.5150,'junction'], ['Industrial Junction',17.4140,78.5150,'junction'],
  ['Airport Road Junction',17.4100,78.4850,'junction'], ['University Junction',17.4580,78.4750,'junction'],
  ['Stadium Junction',17.4380,78.5250,'junction'], ['South Hospital',17.4150,78.5050,'hospital'],
  ['Civic Centre',17.4480,78.5070,'junction'], ['Bus Terminal',17.4250,78.5150,'junction'],
  ['Court Junction',17.4550,78.5200,'junction'], ['Canal Junction',17.4180,78.4780,'junction'],
  ['Fire Station 3',17.4600,78.5250,'fire station'], ['Police HQ',17.4100,78.5200,'police station'],
  ['Hill Junction',17.4700,78.5000,'junction'], ['Library Junction',17.4450,78.4850,'junction'],
  ['Tech Park',17.4350,78.4750,'junction'], ['Depot Junction',17.4050,78.5000,'junction']
];

async function seed() {
  await connectDB();
  await Promise.all([User.deleteMany({}), Location.deleteMany({}), Road.deleteMany({})]);
  await User.create([
    { name: 'ClearPath Administrator', email: 'admin@clearpath.demo', password: await bcrypt.hash('ClearPathAdmin123!', 12), role: 'admin' },
    { name: 'ClearPath Demo User', email: 'user@clearpath.demo', password: await bcrypt.hash('ClearPathUser123!', 12), role: 'user' }
  ]);
  const locations = await Location.insertMany(sampleLocations.map(([name,lat,lng,type]) => ({name,lat,lng,type})));
  const roads = [];
  // Build a connected ring and add cross-links to create meaningful alternate paths.
  for (let i = 0; i < locations.length; i++) {
    const j = (i + 1) % locations.length;
    roads.push({ from: locations[i]._id, to: locations[j]._id, distance: Number((0.7 + (i % 5) * 0.25).toFixed(2)),
      baseTime: 2 + (i % 4), trafficLevel: ['low','medium','high'][i % 3], isBlocked: false, bidirectional: true });
    if (i + 4 < locations.length && i % 2 === 0) {
      roads.push({ from: locations[i]._id, to: locations[i + 4]._id, distance: 1.2 + (i % 3) * 0.2,
        baseTime: 3 + (i % 3), trafficLevel: ['low','medium','high'][(i + 1) % 3], isBlocked: false, bidirectional: true });
    }
  }
  await Road.insertMany(roads);
  console.log(`Seeded ${locations.length} locations and ${roads.length} roads.`);
  await mongoose.disconnect();
}
seed().catch(async err => { console.error(err); await mongoose.disconnect(); process.exit(1); });
