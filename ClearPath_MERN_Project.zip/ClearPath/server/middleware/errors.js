export function notFound(req, res) {
  res.status(404).json({ message: `No API route found for ${req.method} ${req.originalUrl}.` });
}

export function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err);
  const status = err.status || (err.name === 'ValidationError' ? 400 : 500);
  if (err.code === 11000) return res.status(409).json({ message: 'That record already exists.' });
  res.status(status).json({
    message: status >= 500 ? 'The server could not complete this request. Please try again.' : err.message,
    ...(process.env.NODE_ENV === 'development' && status >= 500 ? { detail: err.message } : {})
  });
}
