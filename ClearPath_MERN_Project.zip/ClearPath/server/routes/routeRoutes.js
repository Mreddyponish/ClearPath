import { Router } from 'express';
import { protect } from '../middleware/auth.js';
import { findRoute, history, deleteHistory } from '../controllers/routeController.js';
const router = Router();
router.post('/find', protect, findRoute);
router.get('/history', protect, history);
router.delete('/history/:id', protect, deleteHistory);
export default router;
