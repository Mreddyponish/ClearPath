import { Router } from 'express';
import { protect, adminOnly } from '../middleware/auth.js';
import { summary } from '../controllers/analyticsController.js';
const router = Router();
router.get('/summary', protect, adminOnly, summary);
export default router;
