import { Router } from 'express';
import { protect, adminOnly } from '../middleware/auth.js';
import {
  listLocations, createLocation, updateLocation, deleteLocation,
  listRoads, createRoad, updateRoad, deleteRoad, toggleBlock
} from '../controllers/networkController.js';
const router = Router();
router.get('/locations', listLocations);
router.post('/locations', protect, adminOnly, createLocation);
router.put('/locations/:id', protect, adminOnly, updateLocation);
router.delete('/locations/:id', protect, adminOnly, deleteLocation);
router.get('/roads', listRoads);
router.post('/roads', protect, adminOnly, createRoad);
router.put('/roads/:id', protect, adminOnly, updateRoad);
router.delete('/roads/:id', protect, adminOnly, deleteRoad);
router.patch('/roads/:id/block', protect, adminOnly, toggleBlock);
export default router;
