import test from 'node:test';
import assert from 'node:assert/strict';
import { findShortestPath } from './dijkstra.js';

const locations = [{ id: 'A' }, { id: 'B' }, { id: 'C' }, { id: 'D' }];
const roads = [
  { id: 'AB', from: 'A', to: 'B', distance: 1, baseTime: 1, trafficLevel: 'low', isBlocked: false },
  { id: 'BC', from: 'B', to: 'C', distance: 1, baseTime: 1, trafficLevel: 'low', isBlocked: false },
  { id: 'AD', from: 'A', to: 'D', distance: 2, baseTime: 2, trafficLevel: 'low', isBlocked: false },
  { id: 'DC', from: 'D', to: 'C', distance: 2, baseTime: 2, trafficLevel: 'low', isBlocked: false }
];

test('finds a route between connected locations', () => {
  const result = findShortestPath({ locations, roads, sourceId: 'A', destinationId: 'C', emergencyType: 'ambulance' });
  assert.deepEqual(result.path, ['A', 'B', 'C']);
});
test('excludes blocked roads', () => {
  const result = findShortestPath({ locations, roads: roads.map(r => r.id === 'AB' ? {...r, isBlocked: true} : r), sourceId: 'A', destinationId: 'C', emergencyType: 'ambulance' });
  assert.deepEqual(result.path, ['A', 'D', 'C']);
});
test('returns null for an unreachable destination', () => {
  const result = findShortestPath({ locations, roads: [], sourceId: 'A', destinationId: 'C' });
  assert.equal(result, null);
});
test('returns a zero-cost path when source equals destination', () => {
  const result = findShortestPath({ locations, roads, sourceId: 'A', destinationId: 'A' });
  assert.deepEqual(result.path, ['A']);
  assert.equal(result.cost, 0);
});
