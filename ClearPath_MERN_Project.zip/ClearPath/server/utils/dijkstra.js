// Dijkstra's algorithm using a binary min-heap. All edge costs must be non-negative.
class MinHeap {
  constructor() { this.items = []; }
  push(item) {
    this.items.push(item);
    let i = this.items.length - 1;
    while (i > 0) {
      const p = Math.floor((i - 1) / 2);
      if (this.items[p].cost <= this.items[i].cost) break;
      [this.items[p], this.items[i]] = [this.items[i], this.items[p]];
      i = p;
    }
  }
  pop() {
    if (!this.items.length) return null;
    const top = this.items[0];
    const last = this.items.pop();
    if (this.items.length) {
      this.items[0] = last;
      let i = 0;
      while (true) {
        let smallest = i, l = 2 * i + 1, r = l + 1;
        if (l < this.items.length && this.items[l].cost < this.items[smallest].cost) smallest = l;
        if (r < this.items.length && this.items[r].cost < this.items[smallest].cost) smallest = r;
        if (smallest === i) break;
        [this.items[i], this.items[smallest]] = [this.items[smallest], this.items[i]];
        i = smallest;
      }
    }
    return top;
  }
  get size() { return this.items.length; }
}

export function edgeCost(road, emergencyType) {
  const trafficPenalty = { low: 1, medium: 1.2, high: 1.6 }[road.trafficLevel] ?? 1;
  if (emergencyType === 'ambulance') return road.baseTime * (road.trafficLevel === 'high' ? 2.2 : trafficPenalty);
  if (emergencyType === 'fire') return road.distance * trafficPenalty;
  // Police balances time and distance; the distance component is scaled to kilometres.
  return (road.baseTime * 0.65) + (road.distance * 0.35 * 2) + (trafficPenalty - 1) * road.baseTime;
}

export function findShortestPath({ locations, roads, sourceId, destinationId, emergencyType = 'ambulance', excludedRoadIds = new Set() }) {
  const ids = new Set(locations.map(x => String(x._id ?? x.id)));
  if (!ids.has(String(sourceId)) || !ids.has(String(destinationId))) return null;
  if (String(sourceId) === String(destinationId)) return { path: [String(sourceId)], cost: 0, roads: [] };
  const graph = new Map([...ids].map(id => [id, []]));
  for (const road of roads) {
    if (road.isBlocked || excludedRoadIds.has(String(road._id ?? road.id))) continue;
    const from = String(road.from?._id ?? road.from);
    const to = String(road.to?._id ?? road.to);
    if (!graph.has(from) || !graph.has(to)) continue;
    graph.get(from).push({ to, road, cost: edgeCost(road, emergencyType) });
    if (road.bidirectional !== false) graph.get(to).push({ to: from, road, cost: edgeCost(road, emergencyType) });
  }
  const distances = new Map([...ids].map(id => [id, Infinity]));
  const previous = new Map();
  const heap = new MinHeap();
  distances.set(String(sourceId), 0);
  heap.push({ id: String(sourceId), cost: 0 });
  while (heap.size) {
    const current = heap.pop();
    if (current.cost !== distances.get(current.id)) continue;
    if (current.id === String(destinationId)) break;
    for (const edge of graph.get(current.id) ?? []) {
      const nextCost = current.cost + edge.cost;
      if (nextCost < distances.get(edge.to)) {
        distances.set(edge.to, nextCost);
        previous.set(edge.to, { id: current.id, road: edge.road });
        heap.push({ id: edge.to, cost: nextCost });
      }
    }
  }
  if (!Number.isFinite(distances.get(String(destinationId)))) return null;
  const path = [], usedRoads = [];
  let cursor = String(destinationId);
  path.unshift(cursor);
  while (cursor !== String(sourceId)) {
    const item = previous.get(cursor);
    if (!item) return null;
    usedRoads.unshift(item.road);
    cursor = item.id;
    path.unshift(cursor);
  }
  return { path, cost: distances.get(String(destinationId)), roads: usedRoads };
}

export function summarizePath(pathResult) {
  if (!pathResult) return null;
  return {
    totalDistance: Number(pathResult.roads.reduce((sum, road) => sum + Number(road.distance), 0).toFixed(2)),
    eta: Number(pathResult.roads.reduce((sum, road) => {
      const trafficFactor = { low: 1, medium: 1.2, high: 1.6 }[road.trafficLevel] ?? 1;
      return sum + Number(road.baseTime) * trafficFactor;
    }, 0).toFixed(1))
  };
}

export function findAlternatePath(args, primary) {
  if (!primary || primary.roads.length === 0) return null;
  const candidates = [];
  for (const road of primary.roads) {
    const excluded = new Set([...(args.excludedRoadIds ?? []), String(road._id ?? road.id)]);
    const candidate = findShortestPath({ ...args, excludedRoadIds: excluded });
    if (candidate && candidate.path.join('|') !== primary.path.join('|')) candidates.push(candidate);
  }
  candidates.sort((a, b) => a.cost - b.cost);
  return candidates[0] ?? null;
}
